#!/bin/bash


# Por primera vez crea el archivo backup.log

touch /var/log/backup.log


# Generar log

generate_log(){
	echo "$(date +"%T") - $1" >> /var/log/backup.log
}


# Enviar el log por mail a root

send_log(){
	cat /var/log/backup.log | mail -s "Backup Log" root
}


# Validar directorios origen y destino

validate_directories(){
	if ! test -d "$1"; then
		generate_log "No se encontro el directorio de origen '$1'"
		return 1
	fi
	
	if ! test -d "$2"; then
		generate_log "No se encontro el directorio de destino '$2'"
		return 1
	fi

	if ! df -P "$1" >/dev/null; then
		generate_log "El directorio de origen '$1' no esta montado"
		return 1
	fi

	if ! df -P "$2" >/dev/null; then
		generate_log "El directorio de destino '$2' no esta montado"
		return 1
	fi
}


# Realizar el backup

perform_backup(){
	local src_dir="$1"
	local dest_dir="$2"
	local base_dir=$(basename "$src_dir")
	local backup_file="${base_dir}_bkp_$(date +"%Y%m%d").tar.gz"

	tar -czf "$dest_dir/$backup_file" -C "$src_dir" .
	generate_log "Backup realizado: $src_dir -> $dest_dir/$backup_file"
}


# Procesar los parametros

process_arguments(){
	local src_dir="$1"
	local dest_dir="$2"

	validate_directories "$src_dir" "$dest_dir" || return 1
	perform_backup "$src_dir" "$dest_dir"
}


# Procesar parametro de ayuda

process_help(){
	echo "Invocacion: backup_full.sh <directorio_origen> <directorio_destino>"
	echo "Ejemplo: backup_full.sh /ruta/origen /ruta/destino"
	echo ""
	echo "-h muestra esta ayuda"
}



main(){
	generate_log "Ejecutando script backup_full.sh ..."
	
	if [[ $# -eq 2 ]]; then
		process_arguments "$1" "$2"
	elif [[ $# -eq 1 && $1 == "-h" ]]; then
		process_help
	else
		generate_log "Parametros no validos"
		process_help
	fi

	generate_log "Fin de ejecucion"
	send_log
}

main "$@"

