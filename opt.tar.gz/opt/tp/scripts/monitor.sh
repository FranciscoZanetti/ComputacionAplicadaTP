#!/bin/bash

# Script para monitorear procesos


# Verifica si se paso un parametro
if [ $# -eq 1 ]; then
        parametro="$1"

        #Verifica si el proceso esta en ejecucion
        if ! pgrep -x "$parametro" >/dev/null; then
                echo "El proceso $parametro no esta en ejecucion." | mail -s "Alerta de Monitoreo de procesos" root
        fi

	# Verifica si el parametro es un servicio
	if systemctl list-unit-files | grep -q "\<$parametro\.service\>"; then

	        # Verifica si el servicio no está activo
        	if ! systemctl is-active --quiet "$parametro"; then
			echo "El servicio $parametro no se encuentra activo." | mail -s "Alerta de Monitoreo de servicios" root
		fi
	fi
else
        echo "Se debe pasar un proceso como argumento."
        exit 1
fi

